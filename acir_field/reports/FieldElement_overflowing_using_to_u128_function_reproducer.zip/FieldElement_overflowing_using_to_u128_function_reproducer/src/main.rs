use acir_field::FieldElement;

fn main() {
    println!("-------------------------------------------------------------");
    // Using the u128 max value
    println!("field_element value: {:?}", FieldElement::from(u128::MAX));
    println!("to_u128 output: {:?}", FieldElement::from(u128::MAX));
    println!("try_into_u128 output: {:?}", FieldElement::from(u128::MAX));

    println!("-------------------------------------------------------------");
    // Using the u128 max value + 1
    println!("field_element value: {:?}", FieldElement::try_from_str("340282366920938463463374607431768211456").unwrap());
    println!("to_u128 output: {:?}", FieldElement::try_from_str("340282366920938463463374607431768211456").unwrap().to_u128());
    println!("try_into_u128 output: {:?}", FieldElement::try_from_str("340282366920938463463374607431768211456").unwrap().try_into_u128());

    println!("-------------------------------------------------------------");
    // Using the u128 max value + 2
    println!("field_element value: {:?}", FieldElement::try_from_str("340282366920938463463374607431768211457").unwrap());
    println!("to_u128 output: {:?}", FieldElement::try_from_str("340282366920938463463374607431768211457").unwrap().to_u128());
    println!("try_into_u128 output: {:?}", FieldElement::try_from_str("340282366920938463463374607431768211457").unwrap().try_into_u128());

    println!("-------------------------------------------------------------");
}
