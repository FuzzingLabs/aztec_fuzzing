use acir::FieldElement;

fn main() {
    let _ = FieldElement::from(i128::MIN);
}
